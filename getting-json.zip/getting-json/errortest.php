<?php
  // This is an example of how to deal with errors in the JSON APi

  require 'vendor/autoload.php';
  use GuzzleHttp\Client;

  // make a Guzzle object
  $client = new Client(['http_errors' => false]);

  // This URL generates a 404 error + a JSON response
  // The json response looks like: {"status":"error","code":"404","message":"Breed not found"}
  $response = $client->get("https://dog.ceo/api/breed/4/images/random");

  // get the status code. this code gives you an idea of what the error is
  $statusCode = $response->getStatusCode();

  if ($statusCode == 200) {
    // cool amazing!
  }
  else if ($statusCode == 404) {
    // if you get a 404 error, then you should do something!
    // examples:
    //  - display an error message to the user
    //  - exit the script?
    //  - something else?


    echo "Got a 404 from the api <br>";

    // show JSON response data. Remember - this is a string.
    // If you want to do something with the data, you need to
    //  - convert to array (or object)
    //  - then parse it
    echo $response->getBody()->getContents();
    die();

  }
  else {
    // If you want, you can also throw a PHP exception
    throw new Exception("Invalid response from api...");
  }

  // put whatever other logic you want here
?>
