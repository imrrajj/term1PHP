<?php

    // import the Guzzle library
    // Guzzle is used for sending/receiving requests from the internet
    require 'vendor/autoload.php';
    use GuzzleHttp\Client;

    // 1. Create a new Guzzle Client object
    //    This object is used to send/receive requests
    $client = new Client(['http_errors' => false]);


    // 2. Tell Guzzle which website you want to visit?
    // In the URL below, the JSON response looks like this:
    /*
    {
      "now": {
        "epoch": 1528430646.7035,
        "slang_date": "today",
        "slang_time": "now",
        "iso8601": "2018-06-08T04:04:06.703538Z",
        "rfc2822": "Fri, 08 Jun 2018 04:04:06 GMT",
        "rfc3339": "2018-06-08T04:04:06.70Z"
      },
      "urls": [
        "\/",
        "\/docs",
        "\/when\/:human-timestamp",
        "\/parse\/:machine-timestamp"
      ]
    }
    */
    $response = $client->get("http://now.httpbin.org/");


    // 3. Do something with the response.
    //    Below are a bunch of examples of different functions you can use

    // ------ COMMANDS FOR LOOKING AT THE JSON RESPONSE
    // ------ These commands are OPTIONAL / NOT REQUIRED, but useful for debugging

    // get the response code (200, 404, 500, etc)
    echo $response->getStatusCode() . "<br>";

    // get the message that goes with the code (OK, Not Found, etc)
    echo $response->getReasonPhrase() . "<br>";

    echo "-------<br>";

    // ------ Below are commands for getting the DATA in the response
    // ------ (eg: The data from the website!)

    // 1. Get the "data".
    //    Notes: this command gives you the data as a STRING.
    $body = $response->getBody()->getContents();

    // 2. Convert the data to an associative array (dictionary)
    //    Notes: $body = a string.  But its super difficult to parse a string.
    //    So, you make your life easier by converting the data to an array
    $data = json_decode($body, true);

    // 3.  Get what you want from the data

    echo $data["now"]["epoch"] . "<br>";          // outputs 1528430646.7035
    echo $data["now"]["slang_date"] . "<br>";     // outputs "today"
    print_r($data["urls"]);                       // "urls" is an ARRAY!!, so we need to use print_r
    echo "<br>";
    echo $data["urls"][2];                         // outputs '\/when\/:human-timestamp'
?>
