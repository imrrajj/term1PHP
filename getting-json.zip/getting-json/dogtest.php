<?php

    // import the Guzzle library
    // Guzzle is used for sending/receiving requests from the internet
    require 'vendor/autoload.php';
    use GuzzleHttp\Client;

    // 1. Create a new Guzzle Client object
    //    This object is used to send/receive requests
    $client = new Client(['http_errors' => false]);


    // 2. Tell Guzzle which website you want to visit?
    // In the URL below, the JSON response looks like this:
    /*
      {
          "status": "success",
          "message": "https://images.dog.ceo/breeds/hound-blood/n02088466_7167.jpg"
      }
    */
    $response = $client->get("https://dog.ceo/api/breed/hound/images/random");


    // 3. Do something with the response.

    // 3a. Get the "data".
    $body = $response->getBody()->getContents();

    // 3b. Convert the data to an associative array (dictionary)
    $data = json_decode($body, true);

    // 3c.  Get what you want from the data

    echo $data["status"] . "<br>";      // outputs "success"
    echo $data["message"] . "<br>";     // outputs "https://dog.ceo/api/breed/hound/images/random"

?>
